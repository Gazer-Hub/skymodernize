SKY Modernize Save Technology - Plain HTML Package
==============================================
1. Upload the entire folder to your hosting (cPanel, Netlify, Vercel)
2. Main file is index.html
3. All images are in images/ folder - your 8 real photos are there
4. To edit phone number: open index.html search for 2348179700908
5. To edit location: search for Challenge Ibadan
6. No React needed - pure HTML/CSS/JS
7. Open index.html in browser to preview offline
